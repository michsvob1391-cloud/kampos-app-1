
import { useState } from 'react'
import { supabase } from '../lib/supabase'

export default function Login(){
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)
  const [error, setError] = useState<string|null>(null)

  const sendMagic = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    const { error } = await supabase.auth.signInWithOtp({ email, options: { emailRedirectTo: window.location.origin } })
    if (error) setError(error.message)
    else setSent(true)
  }

  return (
    <div className="card">
      <h2>Přihlášení e-mailem</h2>
      {sent ? (
        <p>Na <b>{email}</b> jsme poslali magický odkaz. Otevři e-mail a klikni na něj.</p>
      ) : (
        <form onSubmit={sendMagic}>
          <input className="input" placeholder="tvuj@email.cz" value={email} onChange={e=>setEmail(e.target.value)} />
          <button className="btn" type="submit">Poslat odkaz</button>
        </form>
      )}
      {error && <p style={{color:'crimson'}}>{error}</p>}
    </div>
  )
}
