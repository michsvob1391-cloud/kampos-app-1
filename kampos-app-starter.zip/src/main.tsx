
import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, NavLink, Route, Routes, Navigate } from 'react-router-dom'
import './styles.css'
import App from './App'
import Announcements from './pages/Announcements'
import Reservations from './pages/Reservations'
import Admin from './pages/Admin'
import Login from './components/Login'
import { supabase } from './lib/supabase'

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {})
  })
}

function Root() {
  const [email, setEmail] = React.useState<string | null>(null)
  React.useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setEmail(data.user?.email ?? null))
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setEmail(session?.user?.email ?? null)
    })
    return () => sub.subscription.unsubscribe()
  }, [])

  return (
    <BrowserRouter>
      <header>
        <strong>Kampos Logistic</strong>
        <nav style={{display:'flex',gap:8}}>
          <NavLink to="/announcements">Oznámení</NavLink>
          <NavLink to="/reservations">Rezervace</NavLink>
          <NavLink to="/admin">Admin</NavLink>
        </nav>
        <div style={{marginLeft:'auto'}}>
          {email ? (
            <button className="btn secondary" onClick={() => supabase.auth.signOut()}>Odhlásit ({email})</button>
          ) : (
            <NavLink to="/login" className="btn">Přihlásit</NavLink>
          )}
        </div>
      </header>
      <div className="container">
        <Routes>
          <Route path="/" element={<App />} />
          <Route path="/login" element={<Login />} />
          <Route path="/announcements" element={<Announcements />} />
          <Route path="/reservations" element={<Reservations />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </BrowserRouter>
  )
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <Root />
  </React.StrictMode>
)
