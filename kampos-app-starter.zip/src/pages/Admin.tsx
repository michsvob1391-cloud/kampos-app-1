
import { useEffect, useState } from 'react'
import { supabase, getSessionEmail } from '../lib/supabase'

export default function Admin(){
  const [isAdmin, setIsAdmin] = useState<boolean|null>(null)
  const [form, setForm] = useState({ title:'', message:'' })
  const [error, setError] = useState<string|null>(null)
  const [ok, setOk] = useState<string>('')

  useEffect(()=>{
    (async () => {
      const email = await getSessionEmail()
      if (!email) { setIsAdmin(false); return }
      const { data } = await supabase.from('users').select('role').eq('email', email).maybeSingle()
      setIsAdmin(data?.role === 'admin')
    })()
  }, [])

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null); setOk('')
    const { error } = await supabase.from('announcements').insert([{
      title: form.title, message: form.message
    }])
    if (error) setError(error.message)
    else { setOk('Oznámení přidáno.'); setForm({title:'', message:''}) }
  }

  if (isAdmin === null) return <p>Kontroluji oprávnění…</p>
  if (!isAdmin) return <p>Nemáš oprávnění pro vstup do admin části.</p>

  return (
    <div>
      <h2>Admin</h2>
      <div className="card">
        <h3>Nové oznámení</h3>
        <form onSubmit={submit}>
          <input className="input" placeholder="Nadpis" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} required />
          <textarea className="input" placeholder="Text oznámení" rows={5} value={form.message} onChange={e=>setForm({...form, message:e.target.value})} required />
          <button className="btn" type="submit">Publikovat</button>
        </form>
        {error && <p style={{color:'crimson'}}>{error}</p>}
        {ok && <p style={{color:'green'}}>{ok}</p>}
      </div>
    </div>
  )
}
