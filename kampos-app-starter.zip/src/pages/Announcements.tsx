
import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

type Ann = { id: string, title: string, message: string, created_at: string }

export default function Announcements(){
  const [items, setItems] = useState<Ann[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string|null>(null)

  useEffect(()=>{
    (async () => {
      setLoading(true)
      const { data, error } = await supabase
        .from('announcements')
        .select('*')
        .order('created_at', { ascending: false })
      if (error) setError(error.message)
      else setItems(data as Ann[])
      setLoading(false)
    })();
  }, [])

  if (loading) return <p>Načítám…</p>
  if (error) return <p style={{color:'crimson'}}>Chyba: {error}</p>

  return (
    <div>
      <h2>Oznámení</h2>
      {items.map(a => (
        <div className="card" key={a.id}>
          <div style={{opacity:.7,fontSize:12}}>{new Date(a.created_at).toLocaleString()}</div>
          <h3>{a.title}</h3>
          <p>{a.message}</p>
        </div>
      ))}
      {items.length === 0 && <div className="card">Zatím žádná oznámení.</div>}
    </div>
  )
}
