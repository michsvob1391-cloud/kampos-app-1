
import { useEffect, useState } from 'react'
import { supabase, getSessionEmail } from '../lib/supabase'

type Res = { id: string, resource: string, date: string, time_from: string, time_to: string, reserved_by: string|null }

export default function Reservations(){
  const [items, setItems] = useState<Res[]>([])
  const [form, setForm] = useState({ resource:'', date:'', time_from:'', time_to:'' })
  const [error, setError] = useState<string|null>(null)

  async function load(){
    const { data, error } = await supabase.from('reservations').select('*').order('date', {ascending:true}).order('time_from', {ascending:true})
    if (error) setError(error.message)
    else setItems(data as Res[])
  }

  useEffect(()=>{ load() }, [])

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    const email = await getSessionEmail()
    if (!email) { setError('Musíš být přihlášen.'); return }
    const { error } = await supabase.from('reservations').insert([{
      resource: form.resource,
      date: form.date,
      time_from: form.time_from,
      time_to: form.time_to,
      reserved_by: email
    }])
    if (error) setError(error.message)
    else {
      setForm({resource:'',date:'',time_from:'',time_to:''})
      load()
    }
  }

  const remove = async (id: string) => {
    const { error } = await supabase.from('reservations').delete().eq('id', id)
    if (!error) load()
  }

  return (
    <div>
      <h2>Rezervace</h2>
      <div className="card">
        <form onSubmit={submit}>
          <input className="input" placeholder="Místo / budova" value={form.resource} onChange={e=>setForm({...form, resource:e.target.value})} required />
          <input className="input" type="date" value={form.date} onChange={e=>setForm({...form, date:e.target.value})} required />
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
            <input className="input" type="time" value={form.time_from} onChange={e=>setForm({...form, time_from:e.target.value})} required />
            <input className="input" type="time" value={form.time_to} onChange={e=>setForm({...form, time_to:e.target.value})} required />
          </div>
          <button className="btn" type="submit">Rezervovat</button>
        </form>
      </div>

      <div className="card">
        <table>
          <thead><tr><th>Místo</th><th>Datum</th><th>Od</th><th>Do</th><th>Rezervoval</th><th></th></tr></thead>
          <tbody>
            {items.map(r => (
              <tr key={r.id}>
                <td>{r.resource}</td>
                <td>{r.date}</td>
                <td>{r.time_from}</td>
                <td>{r.time_to}</td>
                <td>{r.reserved_by || ''}</td>
                <td><button className="btn secondary" onClick={()=>remove(r.id)}>Smazat</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
