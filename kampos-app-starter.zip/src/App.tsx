
export default function App(){
  return (
    <div className="card">
      <h2>Vítej v aplikaci Kampos</h2>
      <p>Z horní lišty si otevři <b>Oznámení</b>, <b>Rezervace</b> nebo <b>Admin</b>.</p>
      <p>Nejprve se přihlas (tlačítko vpravo nahoře), jinak neuvidíš chráněná data.</p>
    </div>
  )
}
